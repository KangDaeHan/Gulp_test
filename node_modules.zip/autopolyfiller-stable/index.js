module.exports = {
    test: require('./match'),
    polyfill: require('./polyfill'),
    support: require('./support'),
    wrapper: require('./wrapper')
};
