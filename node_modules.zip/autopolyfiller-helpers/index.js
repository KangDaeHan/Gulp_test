module.exports = {
    scannerFactory: require('./lib/scanner-factory'),
    matcher: require('./lib/expression-matcher')
};
